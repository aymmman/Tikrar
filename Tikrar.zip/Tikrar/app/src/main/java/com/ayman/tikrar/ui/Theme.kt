package com.ayman.tikrar.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val Light = lightColorScheme(
    primary = Color(0xFF0D5C55),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCDEBE5),
    onPrimaryContainer = Color(0xFF00201C),
    secondary = Color(0xFFB45309),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFCE7C8),
    onSecondaryContainer = Color(0xFF3A1D00),
    tertiary = Color(0xFFB42318),
    tertiaryContainer = Color(0xFFFDE2DE),
    onTertiaryContainer = Color(0xFF410002),
    background = Color(0xFFF8F6F1),
    onBackground = Color(0xFF1B1C1A),
    surface = Color(0xFFF8F6F1),
    onSurface = Color(0xFF1B1C1A),
    surfaceVariant = Color(0xFFE6E2D9),
    onSurfaceVariant = Color(0xFF4C4A44),
    surfaceContainerLow = Color(0xFFF2EFE8),
    surfaceContainer = Color(0xFFECE8E0),
    surfaceContainerHigh = Color(0xFFE6E2D9),
    outline = Color(0xFF7D7A72),
    outlineVariant = Color(0xFFCFCAC0),
)

private val Dark = darkColorScheme(
    primary = Color(0xFF7DD3C5),
    onPrimary = Color(0xFF003731),
    primaryContainer = Color(0xFF0D4F49),
    onPrimaryContainer = Color(0xFFCDEBE5),
    secondary = Color(0xFFF5B66B),
    onSecondary = Color(0xFF4A2800),
    secondaryContainer = Color(0xFF5E3500),
    onSecondaryContainer = Color(0xFFFCE7C8),
    tertiary = Color(0xFFFFB4AB),
    tertiaryContainer = Color(0xFF7A1A12),
    onTertiaryContainer = Color(0xFFFDE2DE),
    background = Color(0xFF101614),
    onBackground = Color(0xFFE3E3DE),
    surface = Color(0xFF101614),
    onSurface = Color(0xFFE3E3DE),
    surfaceVariant = Color(0xFF2A3230),
    onSurfaceVariant = Color(0xFFBEC6C3),
    surfaceContainerLow = Color(0xFF161D1B),
    surfaceContainer = Color(0xFF1B2220),
    surfaceContainerHigh = Color(0xFF242C2A),
    outline = Color(0xFF89928F),
    outlineVariant = Color(0xFF3B4441),
)

private val TikrarShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(26.dp),
)

@Composable
fun TikrarTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) Dark else Light,
        shapes = TikrarShapes,
        content = content,
    )
}
