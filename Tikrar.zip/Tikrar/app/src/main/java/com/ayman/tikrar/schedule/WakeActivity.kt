package com.ayman.tikrar.schedule

import android.app.Activity
import android.app.KeyguardManager
import android.os.Bundle
import android.view.WindowManager
import com.ayman.tikrar.data.MacroStore
import com.ayman.tikrar.engine.Engine
import com.ayman.tikrar.engine.Notifications

/** Wakes the screen for a scheduled run, asks the lock screen to step aside, then hands over. */
class WakeActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        MacroStore.init(this)
        val id = intent.getStringExtra(EXTRA_ID)
        if (id == null) {
            finish()
            return
        }

        val keyguard = getSystemService(KeyguardManager::class.java)
        if (!keyguard.isKeyguardLocked) {
            go(id)
            return
        }
        keyguard.requestDismissKeyguard(
            this,
            object : KeyguardManager.KeyguardDismissCallback() {
                override fun onDismissSucceeded() = go(id)
                override fun onDismissCancelled() = blocked(id)
                override fun onDismissError() = blocked(id)
            },
        )
    }

    private fun go(id: String) {
        window.decorView.postDelayed({
            Engine.play(applicationContext, id)
            finish()
        }, 600L)
    }

    private fun blocked(id: String) {
        val name = MacroStore.get(id)?.name.orEmpty()
        Notifications.locked(applicationContext, name)
        finish()
    }

    companion object {
        const val EXTRA_ID = "macro_id"
    }
}
