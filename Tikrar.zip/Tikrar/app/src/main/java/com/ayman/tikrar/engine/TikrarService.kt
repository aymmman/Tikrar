package com.ayman.tikrar.engine

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Path
import android.graphics.Point
import android.graphics.Rect
import android.os.Build
import android.util.DisplayMetrics
import android.view.KeyEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.view.inputmethod.InputMethodManager
import com.ayman.tikrar.data.MacroStore
import com.ayman.tikrar.model.Macro
import com.ayman.tikrar.model.Target
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

class TikrarService : AccessibilityService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var recorder: Recorder? = null
    private var playJob: Job? = null

    /** Launchers, system UI and this app: places where taps are never recorded. */
    @Volatile
    internal var hubPackages: Set<String> = emptySet()
        private set

    @Volatile
    internal var keyboardPackages: Set<String> = emptySet()
        private set

    private val labels = HashMap<String, String>()

    override fun onServiceConnected() {
        super.onServiceConnected()
        MacroStore.init(this)
        refreshPackages()
        recorder = Recorder(this)
        Engine.attach(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        recorder?.onEvent(event)
    }

    override fun onInterrupt() = Unit

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (playJob?.isActive == true && event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (event.action == KeyEvent.ACTION_UP) stopPlayback()
            return true
        }
        return false
    }

    override fun onUnbind(intent: Intent?): Boolean {
        Engine.detach(this)
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        Engine.detach(this)
        scope.cancel()
        super.onDestroy()
    }

    internal fun startRecording(): Boolean {
        if (playJob?.isActive == true) return false
        refreshPackages()
        recorder?.start() ?: return false
        performGlobalAction(GLOBAL_ACTION_HOME)
        return true
    }

    internal fun cancelRecording() {
        recorder?.cancel()
    }

    internal fun play(macro: Macro): Boolean {
        if (recorder?.isActive == true) return false
        playJob?.cancel()
        playJob = scope.launch { Player(this@TikrarService).run(macro) }
        return true
    }

    internal fun stopPlayback() {
        playJob?.cancel()
    }

    private fun refreshPackages() {
        val home = runCatching {
            packageManager.queryIntentActivities(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),
                PackageManager.MATCH_ALL,
            ).map { it.activityInfo.packageName }
        }.getOrDefault(emptyList())
        hubPackages = buildSet {
            addAll(home)
            add(packageName)
            add("com.android.systemui")
        }
        keyboardPackages = runCatching {
            getSystemService(InputMethodManager::class.java).inputMethodList.map { it.packageName }.toSet()
        }.getOrDefault(emptySet())
    }

    internal fun appLabel(pkg: String): String = labels.getOrPut(pkg) {
        runCatching {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        }.getOrDefault(pkg)
    }

    internal fun screenSize(): Point {
        val wm = getSystemService(WindowManager::class.java)
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            Point(b.width(), b.height())
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            Point(dm.widthPixels, dm.heightPixels)
        }
    }

    internal fun foregroundPackage(): String? = rootInActiveWindow?.packageName?.toString()

    internal fun roots(): List<AccessibilityNodeInfo> {
        val active = rootInActiveWindow
        val others = runCatching {
            windows.filter { it.type == AccessibilityWindowInfo.TYPE_APPLICATION }.mapNotNull { it.root }
        }.getOrDefault(emptyList())
        return buildList {
            if (active != null) add(active)
            others.forEach { if (it != active) add(it) }
        }
    }

    internal fun describe(node: AccessibilityNodeInfo): Target? {
        val pkg = node.packageName?.toString() ?: return null
        val size = screenSize()
        val r = Rect()
        node.getBoundsInScreen(r)
        return Target(
            pkg = pkg,
            viewId = node.viewIdResourceName,
            label = NodeMatcher.labelOf(node),
            cls = node.className?.toString(),
            path = NodeMatcher.pathOf(node),
            cx = if (size.x > 0) r.exactCenterX() / size.x else 0.5f,
            cy = if (size.y > 0) r.exactCenterY() / size.y else 0.5f,
            clickable = node.isClickable,
        )
    }

    internal suspend fun tapRelative(cx: Float, cy: Float, long: Boolean): Boolean {
        val size = screenSize()
        return tap(cx * size.x, cy * size.y, long)
    }

    internal suspend fun tapNode(node: AccessibilityNodeInfo, long: Boolean): Boolean {
        val r = Rect()
        node.getBoundsInScreen(r)
        if (r.isEmpty) return false
        return tap(r.exactCenterX(), r.exactCenterY(), long)
    }

    internal suspend fun tap(x: Float, y: Float, long: Boolean): Boolean {
        val size = screenSize()
        val path = Path().apply {
            moveTo(x.coerceIn(0f, size.x - 1f), y.coerceIn(0f, size.y - 1f))
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, if (long) 700L else 60L)
        return gesture(GestureDescription.Builder().addStroke(stroke).build())
    }

    internal suspend fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long): Boolean {
        val size = screenSize()
        val maxX = size.x - 1f
        val maxY = size.y - 1f
        val path = Path().apply {
            moveTo(x1.coerceIn(0f, maxX), y1.coerceIn(0f, maxY))
            lineTo(x2.coerceIn(0f, maxX), y2.coerceIn(0f, maxY))
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs)
        return gesture(GestureDescription.Builder().addStroke(stroke).build())
    }

    private suspend fun gesture(desc: GestureDescription): Boolean = suspendCancellableCoroutine { cont ->
        val callback = object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                if (cont.isActive) cont.resume(true)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                if (cont.isActive) cont.resume(false)
            }
        }
        if (!dispatchGesture(desc, callback, null) && cont.isActive) cont.resume(false)
    }
}
