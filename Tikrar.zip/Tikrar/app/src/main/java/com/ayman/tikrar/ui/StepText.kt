package com.ayman.tikrar.ui

import android.content.Context
import android.text.format.DateFormat
import com.ayman.tikrar.R
import com.ayman.tikrar.model.Schedule
import com.ayman.tikrar.model.Step
import com.ayman.tikrar.model.StepType
import java.text.DateFormatSymbols
import java.util.Calendar
import java.util.Locale
import kotlin.math.abs

fun Step.title(ctx: Context): String {
    val label = target?.label
    return when (type) {
        StepType.LAUNCH -> ctx.getString(R.string.step_launch, appLabel ?: pkg ?: "?")
        StepType.CLICK -> when {
            byPosition -> ctx.getString(R.string.step_tap_pos)
            label != null -> ctx.getString(R.string.step_click, label)
            else -> ctx.getString(R.string.step_click_plain)
        }
        StepType.LONG_CLICK -> when {
            byPosition -> ctx.getString(R.string.step_long_pos)
            label != null -> ctx.getString(R.string.step_long, label)
            else -> ctx.getString(R.string.step_long_plain)
        }
        StepType.SET_TEXT -> {
            val t = text
            if (t.isNullOrEmpty()) ctx.getString(R.string.step_text_clear) else ctx.getString(R.string.step_text, t.take(40))
        }
        StepType.SCROLL -> ctx.getString(
            if (abs(scrollY) >= abs(scrollX)) {
                if (scrollY >= 0) R.string.step_scroll_down else R.string.step_scroll_up
            } else {
                if (scrollX >= 0) R.string.step_scroll_right else R.string.step_scroll_left
            },
        )
        StepType.BACK -> ctx.getString(R.string.step_back)
        StepType.HOME -> ctx.getString(R.string.step_home)
        StepType.RECENTS -> ctx.getString(R.string.step_recents)
        StepType.NOTIFICATIONS -> ctx.getString(R.string.step_notifications)
        StepType.WAIT -> ctx.getString(R.string.step_wait, seconds(delayMs))
        StepType.LOCK -> ctx.getString(R.string.step_lock)
        StepType.SCREENSHOT -> ctx.getString(R.string.step_screenshot)
    }
}

fun Step.subtitle(ctx: Context): String {
    val parts = mutableListOf<String>()
    if (type != StepType.LAUNCH && type != StepType.WAIT) appLabel?.let { parts += it }
    if (type != StepType.WAIT) parts += ctx.getString(R.string.after_delay, seconds(delayMs))
    return parts.joinToString(" · ")
}

fun seconds(ms: Long): String = String.format(Locale.getDefault(), "%.1f", ms / 1000.0)

fun scheduleText(ctx: Context, s: Schedule): String {
    if (!s.enabled) return ctx.getString(R.string.schedule_off)
    val time = timeText(ctx, s.hour, s.minute)
    return when {
        s.days.isEmpty() -> ctx.getString(R.string.schedule_once, time)
        s.days.size == 7 -> ctx.getString(R.string.schedule_daily, time)
        else -> {
            val names = DateFormatSymbols.getInstance().shortWeekdays
            val list = weekOrder().filter { it in s.days }.joinToString("، ".takeIf { isArabic(ctx) } ?: ", ") { names[it] }
            ctx.getString(R.string.schedule_days, list, time)
        }
    }
}

fun timeText(ctx: Context, hour: Int, minute: Int): String {
    val c = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, hour)
        set(Calendar.MINUTE, minute)
    }
    return DateFormat.getTimeFormat(ctx).format(c.time)
}

fun weekOrder(): List<Int> {
    val first = Calendar.getInstance().firstDayOfWeek
    return (0 until 7).map { (first - 1 + it) % 7 + 1 }
}

private fun isArabic(ctx: Context) = ctx.resources.configuration.locales[0].language == "ar"

/** Accepts Arabic-Indic digits and either decimal mark. */
fun parseSeconds(raw: String): Double? {
    val normal = buildString {
        raw.trim().forEach { ch ->
            when (ch) {
                in '٠'..'٩' -> append('0' + (ch - '٠'))
                in '۰'..'۹' -> append('0' + (ch - '۰'))
                '٫', ',' -> append('.')
                else -> append(ch)
            }
        }
    }
    return normal.toDoubleOrNull()?.takeIf { it >= 0 }
}

fun editableSeconds(ms: Long): String = String.format(Locale.US, "%.1f", ms / 1000.0)
