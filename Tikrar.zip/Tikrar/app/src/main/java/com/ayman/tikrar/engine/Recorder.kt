package com.ayman.tikrar.engine

import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import com.ayman.tikrar.model.Step
import com.ayman.tikrar.model.StepType

/**
 * Turns the raw accessibility event stream into a clean list of steps.
 * Recording ends by itself as soon as the user comes back to Tikrar.
 */
internal class Recorder(private val svc: TikrarService) {

    private val steps = mutableListOf<Step>()
    private val visitedScreens = HashMap<String, MutableSet<String>>()

    var isActive = false
        private set

    private var leftApp = false
    private var foreground: String? = null
    private var currentScreen: String? = null
    private var lastStepAt = 0L
    private var lastTouchAt = 0L

    fun start() {
        steps.clear()
        visitedScreens.clear()
        leftApp = false
        foreground = svc.packageName
        currentScreen = null
        lastStepAt = now()
        lastTouchAt = 0L
        isActive = true
        publish()
    }

    fun cancel() {
        isActive = false
        steps.clear()
    }

    fun onEvent(e: AccessibilityEvent) {
        if (!isActive) return
        val pkg = e.packageName?.toString() ?: return
        when (e.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> onWindow(pkg, e.className?.toString())
            AccessibilityEvent.TYPE_VIEW_CLICKED -> onTouch(e, pkg, long = false)
            AccessibilityEvent.TYPE_VIEW_LONG_CLICKED -> onTouch(e, pkg, long = true)
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> onText(e, pkg)
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> onScroll(e, pkg)
        }
    }

    private fun onWindow(pkg: String, cls: String?) {
        if (pkg in svc.keyboardPackages) return
        if (pkg == svc.packageName) {
            if (leftApp) finish()
            return
        }
        leftApp = true

        if (pkg in svc.hubPackages) {
            foreground = pkg
            currentScreen = null
            return
        }

        val previous = foreground
        if (pkg != previous) {
            if (previous == null || previous in svc.hubPackages) {
                add(Step(StepType.LAUNCH, pkg = pkg, appLabel = svc.appLabel(pkg)))
            }
            foreground = pkg
        } else if (cls != null && isScreen(cls) && cls != currentScreen) {
            // Same app, an earlier screen came back and nothing was tapped: that was Back.
            val seen = visitedScreens[pkg]
            if (seen != null && cls in seen && now() - lastTouchAt > BACK_GAP_MS) {
                add(Step(StepType.BACK))
            }
        }

        if (cls != null && isScreen(cls)) {
            visitedScreens.getOrPut(pkg) { HashSet() }.add(cls)
            currentScreen = cls
        }
    }

    private fun onTouch(e: AccessibilityEvent, pkg: String, long: Boolean) {
        if (!recordable(pkg)) return
        lastTouchAt = now()
        val node = e.source ?: return
        val target = svc.describe(node) ?: return
        add(
            Step(
                type = if (long) StepType.LONG_CLICK else StepType.CLICK,
                pkg = pkg,
                appLabel = svc.appLabel(pkg),
                target = target,
            ),
        )
    }

    private fun onText(e: AccessibilityEvent, pkg: String) {
        if (!recordable(pkg) || e.isPassword) return
        val node = e.source ?: return
        if (node.isPassword) return
        lastTouchAt = now()
        val value = node.text?.toString() ?: e.text.joinToString("")
        val target = svc.describe(node) ?: return

        val last = steps.lastOrNull()
        if (last != null && last.type == StepType.SET_TEXT && last.pkg == pkg && last.target?.path == target.path) {
            steps[steps.lastIndex] = last.copy(text = value)
            lastStepAt = now()
            return
        }
        add(Step(StepType.SET_TEXT, pkg = pkg, appLabel = svc.appLabel(pkg), target = target, text = value))
    }

    private fun onScroll(e: AccessibilityEvent, pkg: String) {
        if (!recordable(pkg)) return
        val dx = e.scrollDeltaX
        val dy = e.scrollDeltaY
        if (dx == 0 && dy == 0) return
        val node = e.source ?: return
        val target = svc.describe(node) ?: return

        val last = steps.lastOrNull()
        if (last != null && last.type == StepType.SCROLL && last.pkg == pkg &&
            last.target?.path == target.path && now() - lastStepAt < SCROLL_MERGE_MS
        ) {
            steps[steps.lastIndex] = last.copy(scrollX = last.scrollX + dx, scrollY = last.scrollY + dy)
            lastStepAt = now()
            return
        }
        add(Step(StepType.SCROLL, pkg = pkg, appLabel = svc.appLabel(pkg), target = target, scrollX = dx, scrollY = dy))
    }

    private fun recordable(pkg: String) =
        pkg !in svc.hubPackages && pkg !in svc.keyboardPackages && pkg != svc.packageName

    private fun isScreen(cls: String) = !cls.startsWith("android.") && !cls.startsWith("androidx.")

    private fun add(step: Step) {
        if (steps.size >= MAX_STEPS) return
        val t = now()
        steps += step.copy(delayMs = (t - lastStepAt).coerceIn(0L, 120_000L))
        lastStepAt = t
        publish()
    }

    private fun finish() {
        isActive = false
        while (steps.lastOrNull()?.type == StepType.BACK) steps.removeAt(steps.lastIndex)
        Engine.recordingState.value = RecState.Done(steps.toList())
        steps.clear()
    }

    private fun publish() {
        Engine.recordingState.value = RecState.Active(steps.size)
    }

    private fun now() = SystemClock.uptimeMillis()

    private companion object {
        const val MAX_STEPS = 400
        const val BACK_GAP_MS = 1_500L
        const val SCROLL_MERGE_MS = 2_000L
    }
}
