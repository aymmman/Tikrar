package com.ayman.tikrar.data

import android.content.Context
import android.util.AtomicFile
import com.ayman.tikrar.model.Macro
import com.ayman.tikrar.model.MacroJson
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.IOException

/** Small JSON-backed store. Everything lives in the app's private files folder. */
object MacroStore {

    private lateinit var file: AtomicFile
    private val state = MutableStateFlow<List<Macro>>(emptyList())
    val macros: StateFlow<List<Macro>> = state.asStateFlow()

    @Volatile
    private var ready = false

    fun init(context: Context) {
        if (ready) return
        synchronized(this) {
            if (ready) return
            file = AtomicFile(File(context.applicationContext.filesDir, "macros.json"))
            state.value = read()
            ready = true
        }
    }

    fun get(id: String): Macro? = state.value.firstOrNull { it.id == id }

    fun upsert(macro: Macro) = synchronized(this) {
        val list = state.value.toMutableList()
        val at = list.indexOfFirst { it.id == macro.id }
        if (at >= 0) list[at] = macro else list.add(0, macro)
        state.value = list
        write(list)
    }

    fun delete(id: String) = synchronized(this) {
        val list = state.value.filterNot { it.id == id }
        state.value = list
        write(list)
    }

    private fun read(): List<Macro> = runCatching {
        if (!file.baseFile.exists()) emptyList() else MacroJson.decode(file.readFully().decodeToString())
    }.getOrDefault(emptyList())

    private fun write(list: List<Macro>) {
        val out = try {
            file.startWrite()
        } catch (_: IOException) {
            return
        }
        try {
            out.write(MacroJson.encode(list).encodeToByteArray())
            file.finishWrite(out)
        } catch (_: IOException) {
            file.failWrite(out)
        }
    }
}
