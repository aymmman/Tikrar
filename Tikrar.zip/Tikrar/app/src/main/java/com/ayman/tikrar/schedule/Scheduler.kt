package com.ayman.tikrar.schedule

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import com.ayman.tikrar.data.MacroStore
import com.ayman.tikrar.engine.Engine
import com.ayman.tikrar.model.Macro
import com.ayman.tikrar.model.Schedule
import java.util.Calendar

object Scheduler {

    internal const val EXTRA_ID = "macro_id"

    fun apply(ctx: Context, macro: Macro) {
        cancel(ctx, macro.id)
        if (!macro.schedule.enabled || macro.steps.isEmpty()) return
        val at = nextRun(macro.schedule, System.currentTimeMillis())
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = pending(ctx, macro.id)
        runCatching {
            if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        }
    }

    fun cancel(ctx: Context, id: String) {
        ctx.getSystemService(AlarmManager::class.java).cancel(pending(ctx, id))
    }

    fun rescheduleAll(ctx: Context) {
        MacroStore.macros.value.forEach { apply(ctx, it) }
    }

    fun nextRun(s: Schedule, from: Long): Long {
        val c = Calendar.getInstance().apply {
            timeInMillis = from
            set(Calendar.HOUR_OF_DAY, s.hour)
            set(Calendar.MINUTE, s.minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        repeat(8) {
            if (c.timeInMillis > from && (s.days.isEmpty() || c.get(Calendar.DAY_OF_WEEK) in s.days)) {
                return c.timeInMillis
            }
            c.add(Calendar.DAY_OF_YEAR, 1)
        }
        return c.timeInMillis
    }

    private fun pending(ctx: Context, id: String): PendingIntent {
        val intent = Intent(ctx, AlarmReceiver::class.java)
            .setData(Uri.parse("tikrar://macro/$id"))
            .putExtra(EXTRA_ID, id)
        return PendingIntent.getBroadcast(
            ctx, 0, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        MacroStore.init(context)
        val id = intent.getStringExtra(Scheduler.EXTRA_ID) ?: return
        val macro = MacroStore.get(id) ?: return
        if (!macro.schedule.enabled) return
        if (macro.schedule.days.isEmpty()) {
            MacroStore.upsert(macro.copy(schedule = macro.schedule.copy(enabled = false)))
        } else {
            Scheduler.apply(context, macro)
        }
        Engine.runFromBackground(context, id)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            -> {
                MacroStore.init(context)
                Scheduler.rescheduleAll(context)
            }
        }
    }
}
