package com.ayman.tikrar.model

import org.json.JSONArray
import org.json.JSONObject

internal object MacroJson {

    private const val FORMAT = 1

    fun encode(list: List<Macro>): String {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        return JSONObject().put("v", FORMAT).put("macros", arr).toString()
    }

    fun decode(raw: String): List<Macro> {
        val arr = JSONObject(raw).optJSONArray("macros") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            runCatching { arr.getJSONObject(i).toMacro() }.getOrNull()
        }
    }

    private fun Macro.toJson(): JSONObject {
        val stepsArr = JSONArray()
        steps.forEach { stepsArr.put(it.toJson()) }
        val sched = JSONObject()
            .put("on", schedule.enabled)
            .put("h", schedule.hour)
            .put("m", schedule.minute)
            .put("days", JSONArray(schedule.days.sorted()))
        return JSONObject()
            .put("id", id)
            .put("name", name)
            .put("createdAt", createdAt)
            .put("repeat", repeat)
            .put("smart", smartTiming)
            .put("schedule", sched)
            .put("steps", stepsArr)
    }

    private fun Step.toJson(): JSONObject {
        val o = JSONObject()
            .put("t", type.name)
            .put("d", delayMs)
            .put("fd", fixedDelay)
            .put("to", timeoutMs)
            .put("sx", scrollX)
            .put("sy", scrollY)
            .put("pos", byPosition)
            .put("fresh", fresh)
            .putOpt("pkg", pkg)
            .putOpt("app", appLabel)
            .putOpt("txt", text)
        target?.let { o.put("tg", it.toJson()) }
        return o
    }

    private fun Target.toJson(): JSONObject = JSONObject()
        .put("pkg", pkg)
        .put("path", path)
        .put("cx", cx.toDouble())
        .put("cy", cy.toDouble())
        .put("ck", clickable)
        .putOpt("id", viewId)
        .putOpt("label", label)
        .putOpt("cls", cls)

    private fun JSONObject.toMacro(): Macro {
        val s = optJSONObject("schedule")
        val days = s?.optJSONArray("days")?.let { a -> (0 until a.length()).map { a.getInt(it) }.toSet() }
        val stepsArr = optJSONArray("steps") ?: JSONArray()
        return Macro(
            id = getString("id"),
            name = getString("name"),
            createdAt = optLong("createdAt"),
            repeat = optInt("repeat", 1),
            smartTiming = optBoolean("smart", true),
            schedule = Schedule(
                enabled = s?.optBoolean("on") ?: false,
                hour = s?.optInt("h", 8) ?: 8,
                minute = s?.optInt("m", 0) ?: 0,
                days = days ?: emptySet(),
            ),
            steps = (0 until stepsArr.length()).mapNotNull { i ->
                runCatching { stepsArr.getJSONObject(i).toStep() }.getOrNull()
            },
        )
    }

    private fun JSONObject.toStep() = Step(
        type = StepType.valueOf(getString("t")),
        delayMs = optLong("d"),
        fixedDelay = optBoolean("fd"),
        timeoutMs = optLong("to", Step.DEFAULT_TIMEOUT),
        pkg = str("pkg"),
        appLabel = str("app"),
        text = str("txt"),
        scrollX = optInt("sx"),
        scrollY = optInt("sy"),
        byPosition = optBoolean("pos"),
        fresh = optBoolean("fresh", true),
        target = optJSONObject("tg")?.toTarget(),
    )

    private fun JSONObject.toTarget() = Target(
        pkg = getString("pkg"),
        viewId = str("id"),
        label = str("label"),
        cls = str("cls"),
        path = optString("path"),
        cx = optDouble("cx", 0.5).toFloat(),
        cy = optDouble("cy", 0.5).toFloat(),
        clickable = optBoolean("ck", true),
    )

    private fun JSONObject.str(key: String): String? =
        if (has(key) && !isNull(key)) getString(key) else null
}
