package com.ayman.tikrar.engine

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import com.ayman.tikrar.model.Target
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Finds a recorded view again on the live screen.
 * Each candidate is scored on resource id, visible label, class, tree path and position,
 * so a button still matches after the layout shifts or the app updates.
 */
internal object NodeMatcher {

    private const val MAX_NODES = 4000
    private val spaces = Regex("\\s+")

    fun find(
        roots: List<AccessibilityNodeInfo>,
        target: Target,
        width: Int,
        height: Int,
        editable: Boolean = false,
    ): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        var bestScore = Int.MIN_VALUE
        var seen = 0
        val bounds = Rect()

        for (root in roots) {
            if (root.packageName?.toString() != target.pkg) continue
            val stack = ArrayDeque<Pair<AccessibilityNodeInfo, String>>()
            stack.addLast(root to "")
            while (stack.isNotEmpty() && seen < MAX_NODES) {
                val (node, path) = stack.removeLast()
                seen++
                val s = score(node, path, target, width, height, editable, bounds)
                if (s != null && s > bestScore) {
                    bestScore = s
                    best = node
                }
                for (i in node.childCount - 1 downTo 0) {
                    val child = node.getChild(i) ?: continue
                    stack.addLast(child to if (path.isEmpty()) "$i" else "$path/$i")
                }
            }
        }
        return best
    }

    private fun score(
        n: AccessibilityNodeInfo,
        path: String,
        t: Target,
        w: Int,
        h: Int,
        editable: Boolean,
        r: Rect,
    ): Int? {
        if (!n.isVisibleToUser) return null
        if (editable && !n.isEditable) return null

        val id = n.viewIdResourceName
        if (t.viewId != null && id != null && id != t.viewId) return null

        var s = 0
        var strong = false

        if (t.viewId != null && id == t.viewId) {
            s += 40
            strong = true
        }

        val wanted = t.label
        if (wanted != null) {
            val have = labelOf(n, deep = n.isClickable || n.isLongClickable || n.isEditable)
            when {
                have == null -> s -= 5
                have.equals(wanted, ignoreCase = true) -> {
                    s += 35
                    strong = true
                }
                have.contains(wanted, ignoreCase = true) || wanted.contains(have, ignoreCase = true) -> s += 10
                else -> s -= 12
            }
        }

        if (t.cls != null && n.className?.toString() == t.cls) s += 6
        if (path == t.path) s += 14
        if (n.isClickable == t.clickable) s += 3

        n.getBoundsInScreen(r)
        if (!r.isEmpty && w > 0 && h > 0) {
            val dx = r.exactCenterX() / w - t.cx
            val dy = r.exactCenterY() / h - t.cy
            val d = sqrt(dx * dx + dy * dy)
            s += ((1f - (d / 0.5f).coerceAtMost(1f)) * 15f).roundToInt()
        }

        val identified = t.viewId != null || t.label != null
        val ok = if (identified) strong && s >= 38 else path == t.path && s >= 20
        return if (ok) s else null
    }

    /** Text a person would read on this view. Edit fields use their hint, never the typed text. */
    fun labelOf(n: AccessibilityNodeInfo, deep: Boolean = true): String? {
        if (n.isEditable) return clean(n.hintText) ?: clean(n.contentDescription)
        clean(n.text)?.let { return it }
        clean(n.contentDescription)?.let { return it }
        if (!deep) return null

        val queue = ArrayDeque<Pair<AccessibilityNodeInfo, Int>>()
        for (i in 0 until n.childCount) n.getChild(i)?.let { queue.addLast(it to 1) }
        var looked = 0
        while (queue.isNotEmpty() && looked < 30) {
            val (c, depth) = queue.removeFirst()
            looked++
            (clean(c.text) ?: clean(c.contentDescription))?.let { return it }
            if (depth < 3) for (i in 0 until c.childCount) c.getChild(i)?.let { queue.addLast(it to depth + 1) }
        }
        return null
    }

    fun pathOf(node: AccessibilityNodeInfo): String {
        val parts = ArrayList<Int>()
        var cur = node
        var guard = 0
        while (guard++ < 60) {
            val parent = cur.parent ?: break
            var index = -1
            for (i in 0 until parent.childCount) {
                if (parent.getChild(i) == cur) {
                    index = i
                    break
                }
            }
            parts.add(index)
            cur = parent
        }
        parts.reverse()
        return parts.joinToString("/")
    }

    private fun clean(cs: CharSequence?): String? =
        cs?.toString()?.replace(spaces, " ")?.trim()?.take(80)?.ifEmpty { null }
}
