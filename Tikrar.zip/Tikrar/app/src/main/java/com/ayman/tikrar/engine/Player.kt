package com.ayman.tikrar.engine

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Rect
import android.os.Bundle
import android.os.SystemClock
import android.view.accessibility.AccessibilityNodeInfo
import com.ayman.tikrar.model.Macro
import com.ayman.tikrar.model.Step
import com.ayman.tikrar.model.StepType
import com.ayman.tikrar.ui.title
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sign

internal class Player(private val svc: TikrarService) {

    suspend fun run(macro: Macro) {
        val total = macro.steps.size
        try {
            repeat(macro.repeat.coerceIn(1, 999)) {
                if (macro.steps.first().type != StepType.LAUNCH && svc.foregroundPackage() == svc.packageName) {
                    svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
                    delay(700)
                }
                macro.steps.forEachIndexed { i, step ->
                    Engine.playingState.value = PlayState(macro.id, macro.name, i + 1, total)
                    Notifications.playing(svc, macro.name, i + 1, total)
                    delay(pauseBefore(step, macro.smartTiming))
                    if (!execute(step)) {
                        Notifications.failed(svc, macro.name, i + 1, step.title(svc))
                        return
                    }
                }
            }
            Notifications.finished(svc, macro.name)
        } catch (c: CancellationException) {
            Notifications.stopped(svc, macro.name)
            throw c
        } finally {
            Engine.playingState.value = null
            Notifications.clearPlaying(svc)
        }
    }

    private fun pauseBefore(step: Step, smart: Boolean): Long = when {
        step.type == StepType.WAIT -> 0L
        !smart || step.fixedDelay -> step.delayMs
        else -> step.delayMs.coerceIn(250L, 1_500L)
    }

    private suspend fun execute(step: Step): Boolean = when (step.type) {
        StepType.LAUNCH -> launch(step)
        StepType.CLICK -> touch(step, long = false)
        StepType.LONG_CLICK -> touch(step, long = true)
        StepType.SET_TEXT -> type(step)
        StepType.SCROLL -> scroll(step)
        StepType.WAIT -> {
            delay(step.delayMs)
            true
        }
        StepType.BACK -> global(AccessibilityService.GLOBAL_ACTION_BACK)
        StepType.HOME -> global(AccessibilityService.GLOBAL_ACTION_HOME)
        StepType.RECENTS -> global(AccessibilityService.GLOBAL_ACTION_RECENTS)
        StepType.NOTIFICATIONS -> global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
        StepType.LOCK -> global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
        StepType.SCREENSHOT -> global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
    }

    private suspend fun global(action: Int): Boolean {
        val ok = svc.performGlobalAction(action)
        delay(400)
        return ok
    }

    private suspend fun launch(step: Step): Boolean {
        val pkg = step.pkg ?: return false
        val intent = svc.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        val taskFlag = if (step.fresh) Intent.FLAG_ACTIVITY_CLEAR_TASK else Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or taskFlag)
        runCatching { svc.startActivity(intent) }.onFailure { return false }
        val arrived = waitFor(step.timeoutMs) { if (svc.foregroundPackage() == pkg) true else null }
        if (arrived == null) return false
        delay(450)
        return true
    }

    private suspend fun touch(step: Step, long: Boolean): Boolean {
        val target = step.target ?: return false
        if (step.byPosition) return svc.tapRelative(target.cx, target.cy, long)

        val size = svc.screenSize()
        val node = waitFor(step.timeoutMs) { NodeMatcher.find(svc.roots(), target, size.x, size.y) }
        if (node == null) {
            // Last resort: same app is on screen, so tap where the finger was.
            return svc.foregroundPackage() == target.pkg && svc.tapRelative(target.cx, target.cy, long)
        }

        val action = if (long) AccessibilityNodeInfo.ACTION_LONG_CLICK else AccessibilityNodeInfo.ACTION_CLICK
        val actor = actionableAncestor(node, long)
        if (actor != null && actor.performAction(action)) return true
        return svc.tapNode(node, long)
    }

    private suspend fun type(step: Step): Boolean {
        val target = step.target ?: return false
        val size = svc.screenSize()
        val node = waitFor(step.timeoutMs) {
            NodeMatcher.find(svc.roots(), target, size.x, size.y, editable = true)
        } ?: return false
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, step.text.orEmpty())
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private suspend fun scroll(step: Step): Boolean {
        val target = step.target ?: return false
        val size = svc.screenSize()
        val node = waitFor(step.timeoutMs) { NodeMatcher.find(svc.roots(), target, size.x, size.y) }
        val area = Rect()
        if (node != null) {
            node.getBoundsInScreen(area)
        } else if (svc.foregroundPackage() == target.pkg) {
            area.set(0, size.y / 5, size.x, size.y * 4 / 5)
        } else {
            return false
        }
        if (area.isEmpty) return false

        var leftX = step.scrollX.toFloat()
        var leftY = step.scrollY.toFloat()
        val stepX = area.width() * 0.7f
        val stepY = area.height() * 0.7f
        var guard = 0
        while ((abs(leftX) > 4f || abs(leftY) > 4f) && guard++ < 12) {
            val mx = sign(leftX) * min(abs(leftX), stepX)
            val my = sign(leftY) * min(abs(leftY), stepY)
            val cx = area.exactCenterX()
            val cy = area.exactCenterY()
            if (!svc.swipe(cx + mx / 2f, cy + my / 2f, cx - mx / 2f, cy - my / 2f, 420L)) return false
            leftX -= mx
            leftY -= my
            delay(220)
        }
        return true
    }

    private fun actionableAncestor(node: AccessibilityNodeInfo, long: Boolean): AccessibilityNodeInfo? {
        var cur: AccessibilityNodeInfo? = node
        var hops = 0
        while (cur != null && hops++ < 6) {
            if (if (long) cur.isLongClickable else cur.isClickable) return cur
            cur = cur.parent
        }
        return null
    }

    private suspend fun <T : Any> waitFor(timeoutMs: Long, probe: () -> T?): T? {
        val deadline = SystemClock.uptimeMillis() + timeoutMs
        while (true) {
            val hit = withContext(Dispatchers.Default) { runCatching(probe).getOrNull() }
            if (hit != null) return hit
            if (SystemClock.uptimeMillis() >= deadline) return null
            delay(POLL_MS)
        }
    }

    private companion object {
        const val POLL_MS = 300L
    }
}
