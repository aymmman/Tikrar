package com.ayman.tikrar.shortcut

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.drawable.Icon
import android.os.Bundle
import android.util.Base64
import android.widget.Toast
import com.ayman.tikrar.R
import com.ayman.tikrar.data.MacroStore
import com.ayman.tikrar.engine.Engine
import com.ayman.tikrar.model.Macro
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Home screen shortcuts. The launcher activity has to be reachable from outside,
 * so every shortcut carries an HMAC that only this install can produce.
 */
object Shortcuts {

    private const val PREFS = "shortcut_keys"
    private const val KEY = "k"
    internal const val ACTION_RUN = "com.ayman.tikrar.RUN"
    internal const val EXTRA_ID = "id"
    internal const val EXTRA_SIG = "sig"

    fun pin(ctx: Context, macro: Macro): Boolean {
        val sm = ctx.getSystemService(ShortcutManager::class.java) ?: return false
        if (!sm.isRequestPinShortcutSupported) return false
        return runCatching { sm.requestPinShortcut(build(ctx, macro), null) }.getOrDefault(false)
    }

    fun refresh(ctx: Context, macro: Macro) {
        val sm = ctx.getSystemService(ShortcutManager::class.java) ?: return
        val sid = shortcutId(macro.id)
        if (sm.pinnedShortcuts.any { it.id == sid }) runCatching { sm.updateShortcuts(listOf(build(ctx, macro))) }
    }

    fun disable(ctx: Context, id: String) {
        val sm = ctx.getSystemService(ShortcutManager::class.java) ?: return
        runCatching { sm.disableShortcuts(listOf(shortcutId(id)), ctx.getString(R.string.shortcut_invalid)) }
    }

    internal fun verify(ctx: Context, id: String, sig: String): Boolean =
        MessageDigest.isEqual(sign(ctx, id).toByteArray(), sig.toByteArray())

    private fun build(ctx: Context, macro: Macro): ShortcutInfo {
        val intent = Intent(ctx, RunShortcutActivity::class.java)
            .setAction(ACTION_RUN)
            .putExtra(EXTRA_ID, macro.id)
            .putExtra(EXTRA_SIG, sign(ctx, macro.id))
        return ShortcutInfo.Builder(ctx, shortcutId(macro.id))
            .setShortLabel(macro.name.take(24))
            .setLongLabel(macro.name.take(60))
            .setIcon(Icon.createWithResource(ctx, R.drawable.ic_shortcut))
            .setIntent(intent)
            .build()
    }

    private fun shortcutId(id: String) = "m_$id"

    private fun sign(ctx: Context, id: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret(ctx), "HmacSHA256"))
        return Base64.encodeToString(mac.doFinal(id.toByteArray()), Base64.NO_WRAP or Base64.URL_SAFE)
    }

    @Synchronized
    private fun secret(ctx: Context): ByteArray {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.getString(KEY, null)?.let { return Base64.decode(it, Base64.NO_WRAP) }
        val fresh = ByteArray(32).also { SecureRandom().nextBytes(it) }
        prefs.edit().putString(KEY, Base64.encodeToString(fresh, Base64.NO_WRAP)).apply()
        return fresh
    }
}

class RunShortcutActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MacroStore.init(this)
        val id = intent?.getStringExtra(Shortcuts.EXTRA_ID)
        val sig = intent?.getStringExtra(Shortcuts.EXTRA_SIG)
        val valid = intent?.action == Shortcuts.ACTION_RUN && id != null && sig != null &&
            Shortcuts.verify(this, id, sig) && MacroStore.get(id) != null
        when {
            !valid -> Toast.makeText(this, R.string.shortcut_invalid, Toast.LENGTH_SHORT).show()
            !Engine.connected.value -> Toast.makeText(this, R.string.notif_service_off, Toast.LENGTH_LONG).show()
            else -> Engine.play(applicationContext, id!!)
        }
        finish()
    }
}
