package com.ayman.tikrar.engine

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import com.ayman.tikrar.R
import com.ayman.tikrar.ui.MainActivity

internal object Notifications {

    private const val CH_PLAY = "playback"
    private const val CH_ALERT = "alerts"
    private const val ID_PLAY = 1001
    private const val ID_RESULT = 1002
    private const val ID_SERVICE = 1003

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannels(
            listOf(
                NotificationChannel(CH_PLAY, ctx.getString(R.string.ch_playback), NotificationManager.IMPORTANCE_LOW),
                NotificationChannel(CH_ALERT, ctx.getString(R.string.ch_alerts), NotificationManager.IMPORTANCE_DEFAULT),
            ),
        )
    }

    fun playing(ctx: Context, name: String, index: Int, total: Int) {
        val stop = PendingIntent.getBroadcast(
            ctx, 0, Intent(ctx, StopReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = Notification.Builder(ctx, CH_PLAY)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(name)
            .setContentText(ctx.getString(R.string.notif_step, index, total))
            .setSubText(ctx.getString(R.string.notif_volume_hint))
            .setProgress(total, index, false)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openApp(ctx))
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(ctx, R.drawable.ic_stop),
                    ctx.getString(R.string.stop),
                    stop,
                ).build(),
            )
            .build()
        post(ctx, ID_PLAY, n)
    }

    fun clearPlaying(ctx: Context) = cancel(ctx, ID_PLAY)

    fun finished(ctx: Context, name: String, handled: Int) = result(
        ctx,
        name,
        if (handled == 0) {
            ctx.getString(R.string.notif_done)
        } else {
            ctx.resources.getQuantityString(R.plurals.notif_done_handled, handled, handled)
        },
    )

    fun stopped(ctx: Context, name: String) =
        result(ctx, name, ctx.getString(R.string.notif_stopped))

    fun failed(ctx: Context, name: String, index: Int, what: String) =
        result(ctx, name, ctx.getString(R.string.notif_failed, index, what))

    fun locked(ctx: Context, name: String) =
        result(ctx, ctx.getString(R.string.app_name), ctx.getString(R.string.notif_locked, name))

    fun serviceOff(ctx: Context) {
        val n = Notification.Builder(ctx, CH_ALERT)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(ctx.getString(R.string.notif_service_off))
            .setContentText(ctx.getString(R.string.notif_service_off_body))
            .setStyle(Notification.BigTextStyle().bigText(ctx.getString(R.string.notif_service_off_body)))
            .setContentIntent(openApp(ctx))
            .setAutoCancel(true)
            .build()
        post(ctx, ID_SERVICE, n)
    }

    private fun result(ctx: Context, title: String, text: String) {
        val n = Notification.Builder(ctx, CH_ALERT)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(openApp(ctx))
            .setAutoCancel(true)
            .setTimeoutAfter(60_000L)
            .build()
        post(ctx, ID_RESULT, n)
    }

    private fun openApp(ctx: Context): PendingIntent = PendingIntent.getActivity(
        ctx, 0,
        Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun post(ctx: Context, id: Int, n: Notification) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (!nm.areNotificationsEnabled()) return
        runCatching { nm.notify(id, n) }
    }

    private fun cancel(ctx: Context, id: Int) {
        ctx.getSystemService(NotificationManager::class.java).cancel(id)
    }
}

class StopReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Engine.stop()
    }
}
