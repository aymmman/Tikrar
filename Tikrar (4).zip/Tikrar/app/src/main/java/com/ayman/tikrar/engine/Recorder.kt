package com.ayman.tikrar.engine

import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import com.ayman.tikrar.model.Step
import com.ayman.tikrar.model.StepType

/**
 * Turns the raw accessibility event stream into a clean list of steps.
 * Recording ends by itself as soon as the user comes back to Tikrar.
 */
internal class Recorder(private val svc: TikrarService) {

    private val steps = mutableListOf<Step>()
    private val visitedScreens = HashMap<String, MutableSet<String>>()

    var isActive = false
        private set

    private var foreground: String? = null
    private var currentScreen: String? = null
    private var lastStepAt = 0L
    private var lastTouchAt = 0L

    // An app that came to the front from the home screen. It only becomes a step once the
    // user actually does something inside it, so overlays like Google feed or assistant
    // windows that flash past while going home are never recorded.
    private var pendingLaunch: String? = null
    private var pendingAt = 0L

    fun start() {
        steps.clear()
        visitedScreens.clear()
        foreground = svc.packageName
        currentScreen = null
        lastStepAt = now()
        lastTouchAt = 0L
        pendingLaunch = null
        isActive = true
        publish()
    }

    fun cancel() {
        isActive = false
        steps.clear()
    }

    fun onEvent(e: AccessibilityEvent) {
        if (!isActive) return
        val pkg = e.packageName?.toString() ?: return
        when (e.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> onWindow(pkg, e.className?.toString())
            AccessibilityEvent.TYPE_VIEW_CLICKED -> onTouch(e, pkg, long = false)
            AccessibilityEvent.TYPE_VIEW_LONG_CLICKED -> onTouch(e, pkg, long = true)
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> onText(e, pkg)
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> onScroll(e, pkg)
        }
    }

    private fun onWindow(pkg: String, cls: String?) {
        if (pkg in svc.keyboardPackages) return
        // Coming back to Tikrar mid-recording is fine; only the Stop button ends it.
        if (pkg == svc.packageName) return

        if (pkg in svc.hubPackages) {
            foreground = pkg
            currentScreen = null
            pendingLaunch = null
            return
        }

        val previous = foreground
        if (pkg != previous) {
            if (previous == null || previous in svc.hubPackages || previous == pendingLaunch) {
                pendingLaunch = pkg
                pendingAt = now()
            }
            foreground = pkg
        } else if (cls != null && isScreen(cls) && cls != currentScreen) {
            // Same app, an earlier screen came back and nothing was tapped: that was Back.
            val seen = visitedScreens[pkg]
            if (seen != null && cls in seen && now() - lastTouchAt > BACK_GAP_MS) {
                add(Step(StepType.BACK))
            }
        }

        if (cls != null && isScreen(cls)) {
            visitedScreens.getOrPut(pkg) { HashSet() }.add(cls)
            currentScreen = cls
        }
    }

    private fun onTouch(e: AccessibilityEvent, pkg: String, long: Boolean) {
        if (!recordable(pkg)) return
        lastTouchAt = now()
        val node = e.source ?: return
        val target = svc.describe(node) ?: return
        commitLaunch(pkg)
        add(
            Step(
                type = if (long) StepType.LONG_CLICK else StepType.CLICK,
                pkg = pkg,
                appLabel = svc.appLabel(pkg),
                target = target,
            ),
        )
    }

    private fun onText(e: AccessibilityEvent, pkg: String) {
        if (!recordable(pkg) || e.isPassword) return
        val node = e.source ?: return
        if (node.isPassword) return
        lastTouchAt = now()
        val value = node.text?.toString() ?: e.text.joinToString("")
        val target = svc.describe(node) ?: return
        commitLaunch(pkg)

        val last = steps.lastOrNull()
        if (last != null && last.type == StepType.SET_TEXT && last.pkg == pkg && last.target?.path == target.path) {
            steps[steps.lastIndex] = last.copy(text = value)
            lastStepAt = now()
            return
        }
        add(Step(StepType.SET_TEXT, pkg = pkg, appLabel = svc.appLabel(pkg), target = target, text = value))
    }

    private fun onScroll(e: AccessibilityEvent, pkg: String) {
        if (!recordable(pkg)) return
        val dx = e.scrollDeltaX
        val dy = e.scrollDeltaY
        if (dx == 0 && dy == 0) return
        val node = e.source ?: return
        val target = svc.describe(node) ?: return
        commitLaunch(pkg)

        val last = steps.lastOrNull()
        if (last != null && last.type == StepType.SCROLL && last.pkg == pkg &&
            last.target?.path == target.path && now() - lastStepAt < SCROLL_MERGE_MS
        ) {
            steps[steps.lastIndex] = last.copy(scrollX = last.scrollX + dx, scrollY = last.scrollY + dy)
            lastStepAt = now()
            return
        }
        add(Step(StepType.SCROLL, pkg = pkg, appLabel = svc.appLabel(pkg), target = target, scrollX = dx, scrollY = dy))
    }

    private fun recordable(pkg: String) =
        pkg !in svc.hubPackages && pkg !in svc.keyboardPackages && pkg != svc.packageName

    private fun isScreen(cls: String) = !cls.startsWith("android.") && !cls.startsWith("androidx.")

    private fun commitLaunch(pkg: String) {
        if (pendingLaunch != pkg) return
        pendingLaunch = null
        add(Step(StepType.LAUNCH, pkg = pkg, appLabel = svc.appLabel(pkg)), at = pendingAt)
    }

    private fun add(step: Step, at: Long = now()) {
        if (steps.size >= MAX_STEPS) return
        steps += step.copy(delayMs = (at - lastStepAt).coerceIn(0L, 120_000L))
        lastStepAt = at
        publish()
    }

    fun finish() {
        if (!isActive) return
        isActive = false
        while (steps.lastOrNull()?.type == StepType.BACK) steps.removeAt(steps.lastIndex)
        // Leave things the way they started: close the last app that was used.
        val lastApp = steps.lastOrNull { it.pkg != null }?.pkg
        if (lastApp != null && steps.last().type != StepType.CLOSE_APP) {
            steps += Step(StepType.CLOSE_APP, delayMs = 800L, pkg = lastApp, appLabel = svc.appLabel(lastApp))
        }
        Engine.recordingState.value = RecState.Done(steps.toList())
        steps.clear()
    }

    private fun publish() {
        Engine.recordingState.value = RecState.Active(steps.size)
        svc.onRecordingCount(steps.size)
    }

    private fun now() = SystemClock.uptimeMillis()

    private companion object {
        const val MAX_STEPS = 400
        const val BACK_GAP_MS = 1_500L
        const val SCROLL_MERGE_MS = 2_000L
    }
}
