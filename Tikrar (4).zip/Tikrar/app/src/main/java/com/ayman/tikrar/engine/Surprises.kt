package com.ayman.tikrar.engine

import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import java.util.Locale

/**
 * Things that pop up during a replay that weren't there while recording:
 * permission prompts, rate-this-app dialogs, update nags, ads, "what's new" sheets.
 * Only consulted once the expected button has been missing for a moment.
 */
internal object Surprises {

    val permissionPackages = setOf(
        "com.google.android.permissioncontroller",
        "com.android.permissioncontroller",
        "com.samsung.android.permissioncontroller",
    )

    private val allowWords = listOf(
        "while using the app", "only this time", "allow",
        "أثناء استخدام التطبيق", "عند استخدام التطبيق", "هذه المرة فقط", "السماح", "سماح",
    )

    // Order matters: the first word that matches wins, so softer choices come first.
    private val dismissWords = listOf(
        "not now", "no thanks", "no, thanks", "maybe later", "remind me later", "later",
        "skip ad", "skip", "close ad", "close", "dismiss", "got it", "ok", "okay",
        "ليس الآن", "ليس الان", "لاحقًا", "لاحقاً", "لاحقا", "ذكرني لاحقًا", "لا شكرًا", "لا، شكرًا", "لا شكرا",
        "تخطي", "تخطّي", "تخطي الإعلان", "إغلاق", "اغلاق", "إغلاق الإعلان", "تجاهل",
        "حسنًا", "حسناً", "حسنا", "موافق", "فهمت",
        "✕", "×",
    )

    private const val MAX_NODES = 1500

    /** Clears one obstacle if it can find one. Returns true when something was tapped. */
    suspend fun clearOne(svc: TikrarService): Boolean {
        for (root in candidateRoots(svc)) {
            val pkg = root.packageName?.toString() ?: continue
            val words = if (pkg in permissionPackages) allowWords else dismissWords
            val node = bestMatch(root, words) ?: continue
            val actor = clickable(node)
            if (actor != null && actor.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            if (svc.tapNode(node, long = false)) return true
        }
        return false
    }

    private fun candidateRoots(svc: TikrarService): List<AccessibilityNodeInfo> {
        val skipTypes = setOf(
            AccessibilityWindowInfo.TYPE_INPUT_METHOD,
            AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY,
            AccessibilityWindowInfo.TYPE_SPLIT_SCREEN_DIVIDER,
        )
        val fromWindows = runCatching {
            svc.windows
                .filter { it.type !in skipTypes }
                .sortedByDescending { it.layer }
                .mapNotNull { it.root }
        }.getOrDefault(emptyList())
        val all = buildList {
            svc.rootInActiveWindow?.let { add(it) }
            fromWindows.forEach { if (it !in this) add(it) }
        }
        return all.filter {
            val p = it.packageName?.toString()
            p != null && p != svc.packageName && p != "com.android.systemui"
        }
    }

    private fun bestMatch(root: AccessibilityNodeInfo, words: List<String>): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        var bestRank = Int.MAX_VALUE
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.addLast(root)
        var seen = 0
        while (stack.isNotEmpty() && seen++ < MAX_NODES) {
            val n = stack.removeLast()
            if (n.isVisibleToUser && !n.isEditable) {
                val label = (n.text ?: n.contentDescription)?.toString()
                    ?.trim()?.lowercase(Locale.ROOT)
                if (!label.isNullOrEmpty() && label.length <= 40) {
                    val rank = words.indexOf(label)
                    if (rank in 0 until bestRank) {
                        bestRank = rank
                        best = n
                    }
                }
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { stack.addLast(it) }
        }
        return best
    }

    private fun clickable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var cur: AccessibilityNodeInfo? = node
        var hops = 0
        while (cur != null && hops++ < 5) {
            if (cur.isClickable) return cur
            cur = cur.parent
        }
        return null
    }
}
