@file:OptIn(ExperimentalMaterial3Api::class)

package com.ayman.tikrar.ui

import android.widget.Toast
import androidx.annotation.DrawableRes
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.ayman.tikrar.R
import com.ayman.tikrar.data.MacroStore
import com.ayman.tikrar.engine.Engine
import com.ayman.tikrar.engine.PlayState
import com.ayman.tikrar.model.Macro
import com.ayman.tikrar.model.Schedule
import com.ayman.tikrar.model.Step
import com.ayman.tikrar.model.StepType
import com.ayman.tikrar.schedule.Scheduler
import com.ayman.tikrar.shortcut.Shortcuts
import java.time.DayOfWeek
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun MacroScreen(macro: Macro, playing: PlayState?, connected: Boolean, onBack: () -> Unit) {
    val context = LocalContext.current
    var renaming by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Int?>(null) }
    var adding by remember { mutableStateOf(false) }
    var pickingApp by remember { mutableStateOf(false) }
    var pickingTime by remember { mutableStateOf(false) }

    fun save(updated: Macro) {
        MacroStore.upsert(updated)
        if (updated.schedule != macro.schedule || updated.steps.isEmpty() != macro.steps.isEmpty()) {
            Scheduler.apply(context, updated)
        }
        if (updated.name != macro.name) Shortcuts.refresh(context, updated)
    }

    fun editSteps(block: MutableList<Step>.() -> Unit) {
        save(macro.copy(steps = macro.steps.toMutableList().apply(block)))
    }

    val isPlaying = playing?.macroId == macro.id

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text(macro.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(painterResource(R.drawable.ic_back), contentDescription = stringResource(R.string.back))
                    }
                },
                actions = {
                    IconButton(onClick = { renaming = true }) {
                        Icon(painterResource(R.drawable.ic_edit), contentDescription = stringResource(R.string.rename))
                    }
                    IconButton(onClick = { confirmDelete = true }) {
                        Icon(painterResource(R.drawable.ic_delete), contentDescription = stringResource(R.string.delete))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
            )
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = padding.calculateTopPadding() + 4.dp,
                bottom = padding.calculateBottomPadding() + 32.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { if (isPlaying) Engine.stop() else Engine.play(context, macro.id) },
                        enabled = isPlaying || (connected && playing == null && macro.steps.isNotEmpty()),
                        modifier = Modifier.weight(1f),
                    ) {
                        Icon(
                            painterResource(if (isPlaying) R.drawable.ic_stop else R.drawable.ic_play),
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(if (isPlaying) R.string.stop else R.string.play))
                    }
                    OutlinedButton(
                        onClick = {
                            if (!Shortcuts.pin(context, macro)) {
                                Toast.makeText(context, R.string.pin_unsupported, Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.weight(1f),
                    ) {
                        Icon(painterResource(R.drawable.ic_pin), contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.pin), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }

            item {
                PlaybackCard(
                    repeat = macro.repeat,
                    smart = macro.smartTiming,
                    autoHandle = macro.autoHandle,
                    onRepeat = { save(macro.copy(repeat = it)) },
                    onSmart = { save(macro.copy(smartTiming = it)) },
                    onAutoHandle = { save(macro.copy(autoHandle = it)) },
                )
            }

            item {
                ScheduleCard(
                    schedule = macro.schedule,
                    onChange = { save(macro.copy(schedule = it)) },
                    onPickTime = { pickingTime = true },
                )
            }

            item {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp, start = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        stringResource(R.string.steps_header),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f),
                    )
                    TextButton(onClick = { adding = true }) {
                        Icon(painterResource(R.drawable.ic_add), contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.add_step))
                    }
                }
            }

            if (macro.steps.isEmpty()) {
                item {
                    Text(
                        stringResource(R.string.no_steps),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 4.dp),
                    )
                }
            }

            itemsIndexed(macro.steps) { i, step ->
                StepRow(
                    index = i,
                    step = step,
                    last = i == macro.steps.lastIndex,
                    current = isPlaying && playing?.index == i + 1,
                    onEdit = { editing = i },
                    onUp = { editSteps { add(i - 1, removeAt(i)) } },
                    onDown = { editSteps { add(i + 1, removeAt(i)) } },
                    onDuplicate = { editSteps { add(i + 1, step) } },
                    onDelete = { editSteps { removeAt(i) } },
                )
            }
        }
    }

    if (renaming) {
        TextInputDialog(
            title = stringResource(R.string.rename),
            initial = macro.name,
            onDismiss = { renaming = false },
            onDone = {
                renaming = false
                save(macro.copy(name = it))
            },
        )
    }

    if (confirmDelete) {
        ConfirmDialog(
            title = stringResource(R.string.delete_macro_title),
            body = stringResource(R.string.delete_macro_body),
            confirm = stringResource(R.string.delete),
            onDismiss = { confirmDelete = false },
            onConfirm = {
                confirmDelete = false
                if (isPlaying) Engine.stop()
                Scheduler.cancel(context, macro.id)
                Shortcuts.disable(context, macro.id)
                MacroStore.delete(macro.id)
                onBack()
            },
        )
    }

    val editIndex = editing
    val editStep = editIndex?.let { macro.steps.getOrNull(it) }
    if (editIndex != null && editStep != null) {
        StepEditDialog(
            step = editStep,
            onDismiss = { editing = null },
            onSave = { updated ->
                editing = null
                editSteps { set(editIndex, updated) }
            },
        )
    }

    if (adding) {
        AddStepDialog(
            onDismiss = { adding = false },
            onPick = { type ->
                adding = false
                when (type) {
                    StepType.LAUNCH -> pickingApp = true
                    StepType.WAIT -> editSteps { add(Step(StepType.WAIT, delayMs = 2_000L, fixedDelay = true)) }
                    else -> editSteps { add(Step(type, delayMs = 500L, fixedDelay = true)) }
                }
            },
        )
    }

    if (pickingApp) {
        AppPickerDialog(
            onDismiss = { pickingApp = false },
            onPick = { pkg, label ->
                pickingApp = false
                editSteps { add(Step(StepType.LAUNCH, delayMs = 500L, fixedDelay = true, pkg = pkg, appLabel = label)) }
            },
        )
    }

    if (pickingTime) {
        TimeDialog(
            hour = macro.schedule.hour,
            minute = macro.schedule.minute,
            onDismiss = { pickingTime = false },
            onDone = { h, m ->
                pickingTime = false
                save(macro.copy(schedule = macro.schedule.copy(hour = h, minute = m, enabled = true)))
            },
        )
    }
}

@Composable
private fun PlaybackCard(
    repeat: Int,
    smart: Boolean,
    autoHandle: Boolean,
    onRepeat: (Int) -> Unit,
    onSmart: (Boolean) -> Unit,
    onAutoHandle: (Boolean) -> Unit,
) {
    SectionCard {
        Text(stringResource(R.string.options), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.repeat), modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
            IconButton(onClick = { onRepeat(repeat - 1) }, enabled = repeat > 1) {
                Icon(painterResource(R.drawable.ic_remove), contentDescription = null)
            }
            Text(
                stringResource(R.string.repeat_times, repeat),
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.width(44.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
            IconButton(onClick = { onRepeat(repeat + 1) }, enabled = repeat < 99) {
                Icon(painterResource(R.drawable.ic_add), contentDescription = null)
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.smart_timing), style = MaterialTheme.typography.bodyLarge)
                Text(
                    stringResource(R.string.smart_timing_body),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Spacer(Modifier.width(12.dp))
            Switch(checked = smart, onCheckedChange = onSmart)
        }
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.auto_handle), style = MaterialTheme.typography.bodyLarge)
                Text(
                    stringResource(R.string.auto_handle_body),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Spacer(Modifier.width(12.dp))
            Switch(checked = autoHandle, onCheckedChange = onAutoHandle)
        }
    }
}

@Composable
private fun ScheduleCard(schedule: Schedule, onChange: (Schedule) -> Unit, onPickTime: () -> Unit) {
    val context = LocalContext.current
    SectionCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.schedule), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(
                    scheduleText(context, schedule),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Switch(checked = schedule.enabled, onCheckedChange = { onChange(schedule.copy(enabled = it)) })
        }
        if (schedule.enabled) {
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier
                    .clip(MaterialTheme.shapes.small)
                    .clickable(onClick = onPickTime)
                    .padding(vertical = 6.dp, horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(painterResource(R.drawable.ic_clock), contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(10.dp))
                Text(
                    timeText(context, schedule.hour, schedule.minute),
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                weekOrder().forEach { day ->
                    val on = day in schedule.days
                    DayDot(
                        label = dayLetter(day),
                        selected = on,
                        onClick = {
                            onChange(schedule.copy(days = if (on) schedule.days - day else schedule.days + day))
                        },
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                stringResource(R.string.days_hint) + "\n" + stringResource(R.string.schedule_lock_note),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun DayDot(label: String, selected: Boolean, onClick: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Box(
        Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(if (selected) scheme.primary else scheme.surfaceContainerHigh)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            style = MaterialTheme.typography.labelLarge,
            color = if (selected) scheme.onPrimary else scheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun StepRow(
    index: Int,
    step: Step,
    last: Boolean,
    current: Boolean,
    onEdit: () -> Unit,
    onUp: () -> Unit,
    onDown: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit,
) {
    val context = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    val scheme = MaterialTheme.colorScheme
    Card(
        onClick = onEdit,
        colors = CardDefaults.cardColors(
            containerColor = if (current) scheme.primaryContainer else scheme.surfaceContainerLow,
        ),
    ) {
        Row(
            Modifier.padding(start = 12.dp, end = 4.dp, top = 10.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(scheme.surfaceContainerHigh),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    painterResource(stepIcon(step.type)),
                    contentDescription = null,
                    tint = scheme.primary,
                    modifier = Modifier.size(20.dp),
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    "${index + 1}. " + step.title(context),
                    style = MaterialTheme.typography.bodyLarge,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                val sub = step.subtitle(context)
                if (sub.isNotEmpty()) {
                    Text(sub, style = MaterialTheme.typography.bodySmall, color = scheme.onSurfaceVariant, maxLines = 1)
                }
            }
            Box {
                IconButton(onClick = { menu = true }) {
                    Icon(painterResource(R.drawable.ic_more), contentDescription = null)
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    MenuItem(R.string.edit_step, R.drawable.ic_edit) { menu = false; onEdit() }
                    MenuItem(R.string.move_up, R.drawable.ic_up, enabled = index > 0) { menu = false; onUp() }
                    MenuItem(R.string.move_down, R.drawable.ic_down, enabled = !last) { menu = false; onDown() }
                    MenuItem(R.string.duplicate, R.drawable.ic_copy) { menu = false; onDuplicate() }
                    MenuItem(R.string.delete, R.drawable.ic_delete) { menu = false; onDelete() }
                }
            }
        }
    }
}

@Composable
private fun MenuItem(text: Int, @DrawableRes icon: Int, enabled: Boolean = true, onClick: () -> Unit) {
    DropdownMenuItem(
        text = { Text(stringResource(text)) },
        onClick = onClick,
        enabled = enabled,
        leadingIcon = { Icon(painterResource(icon), contentDescription = null) },
    )
}

@Composable
private fun SectionCard(content: @Composable () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) { content() }
    }
}

@DrawableRes
fun stepIcon(type: StepType): Int = when (type) {
    StepType.LAUNCH -> R.drawable.ic_apps
    StepType.CLICK, StepType.LONG_CLICK -> R.drawable.ic_tap
    StepType.SET_TEXT -> R.drawable.ic_keyboard
    StepType.SCROLL -> R.drawable.ic_scroll
    StepType.BACK -> R.drawable.ic_back
    StepType.HOME -> R.drawable.ic_home
    StepType.RECENTS -> R.drawable.ic_recents
    StepType.NOTIFICATIONS -> R.drawable.ic_bell
    StepType.WAIT -> R.drawable.ic_wait
    StepType.LOCK -> R.drawable.ic_lock
    StepType.SCREENSHOT -> R.drawable.ic_screenshot
    StepType.CLOSE_APP -> R.drawable.ic_close
}

private fun dayLetter(calendarDay: Int): String {
    val dow = DayOfWeek.of((calendarDay + 5) % 7 + 1)
    return dow.getDisplayName(TextStyle.NARROW, Locale.getDefault())
}
