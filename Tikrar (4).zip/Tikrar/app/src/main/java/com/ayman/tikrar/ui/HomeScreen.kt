@file:OptIn(ExperimentalMaterial3Api::class)

package com.ayman.tikrar.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.font.FontFamily
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.ayman.tikrar.engine.Watchdog
import androidx.compose.material3.ExperimentalMaterial3Api
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.ayman.tikrar.R
import com.ayman.tikrar.engine.Engine
import com.ayman.tikrar.engine.PlayState
import com.ayman.tikrar.engine.RecState
import com.ayman.tikrar.model.Macro

@Composable
fun HomeScreen(
    macros: List<Macro>,
    connected: Boolean,
    recording: RecState,
    playing: PlayState?,
    onOpen: (String) -> Unit,
) {
    val context = LocalContext.current
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        floatingActionButton = {
            if (connected && recording !is RecState.Active && playing == null) {
                ExtendedFloatingActionButton(
                    onClick = {
                        if (!Engine.startRecording()) {
                            Toast.makeText(context, R.string.cant_record_now, Toast.LENGTH_SHORT).show()
                        }
                    },
                    containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                    contentColor = MaterialTheme.colorScheme.onTertiaryContainer,
                    icon = { Icon(painterResource(R.drawable.ic_record), contentDescription = null) },
                    text = { Text(stringResource(R.string.record)) },
                )
            }
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 20.dp,
                end = 20.dp,
                top = padding.calculateTopPadding(),
                bottom = padding.calculateBottomPadding() + 96.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item { Header() }

            if (!connected) item { ServiceCard() }

            item { KeepAliveCard() }

            if (recording is RecState.Active) item { RecordingCard(recording.count) }

            if (playing != null) item { PlayingCard(playing) }

            if (macros.isEmpty()) {
                item { EmptyState(connected) }
            } else {
                items(macros, key = { it.id }) { macro ->
                    MacroCard(
                        macro = macro,
                        isPlaying = playing?.macroId == macro.id,
                        canPlay = connected && playing == null && recording !is RecState.Active,
                        onOpen = { onOpen(macro.id) },
                    )
                }
            }
        }
    }
}

@Composable
private fun Header() {
    Column(
        Modifier
            .statusBarsPadding()
            .padding(top = 20.dp, bottom = 8.dp),
    ) {
        Text(
            stringResource(R.string.app_name),
            style = MaterialTheme.typography.displaySmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
        )
        Spacer(Modifier.height(4.dp))
        Text(
            stringResource(R.string.home_subtitle),
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun ServiceCard() {
    val context = LocalContext.current
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.secondaryContainer,
            contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
        ),
    ) {
        Column(Modifier.padding(18.dp)) {
            Text(stringResource(R.string.service_off_title), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            Text(stringResource(R.string.service_off_body), style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(8.dp))
            Text(
                stringResource(R.string.service_off_hint),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.8f),
            )
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { openAccessibility(context) }) { Text(stringResource(R.string.open_settings)) }
                OutlinedButton(onClick = { openAppInfo(context) }) { Text(stringResource(R.string.open_app_info)) }
            }
        }
    }
}

@Composable
private fun RecordingCard(count: Int) {
    val context = LocalContext.current
    StatusCard(
        dotColor = MaterialTheme.colorScheme.tertiary,
        title = stringResource(R.string.recording_title),
        body = stringResource(R.string.recording_body) + "\n" +
            context.resources.getQuantityString(R.plurals.steps, count, count),
        action = stringResource(R.string.cancel),
        onAction = { Engine.cancelRecording() },
    )
}

@Composable
private fun PlayingCard(state: PlayState) {
    StatusCard(
        dotColor = MaterialTheme.colorScheme.primary,
        title = stringResource(R.string.playing_title, state.name),
        body = stringResource(R.string.notif_step, state.index, state.total) + "\n" +
            stringResource(R.string.notif_volume_hint),
        action = stringResource(R.string.stop),
        onAction = { Engine.stop() },
    )
}

@Composable
private fun StatusCard(
    dotColor: androidx.compose.ui.graphics.Color,
    title: String,
    body: String,
    action: String,
    onAction: () -> Unit,
) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)) {
        Row(Modifier.padding(start = 18.dp, end = 8.dp, top = 14.dp, bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(12.dp)
                    .clip(CircleShape)
                    .background(dotColor),
            )
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton(onClick = onAction) { Text(action) }
        }
    }
}

@Composable
private fun MacroCard(macro: Macro, isPlaying: Boolean, canPlay: Boolean, onOpen: () -> Unit) {
    val context = LocalContext.current
    Card(
        onClick = onOpen,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
    ) {
        Row(Modifier.padding(start = 18.dp, end = 12.dp, top = 14.dp, bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    macro.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    context.resources.getQuantityString(R.plurals.steps, macro.steps.size, macro.steps.size) +
                        "  ·  " + scheduleText(context, macro.schedule),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            FilledIconButton(
                onClick = {
                    if (isPlaying) Engine.stop() else Engine.play(context, macro.id)
                },
                enabled = isPlaying || canPlay,
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                ),
            ) {
                Icon(
                    painterResource(if (isPlaying) R.drawable.ic_stop else R.drawable.ic_play),
                    contentDescription = stringResource(if (isPlaying) R.string.stop else R.string.play),
                )
            }
        }
    }
}

@Composable
private fun EmptyState(connected: Boolean) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(top = 48.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(
            painterResource(R.drawable.ic_tap),
            contentDescription = null,
            tint = MaterialTheme.colorScheme.outline,
            modifier = Modifier.size(56.dp),
        )
        Spacer(Modifier.height(14.dp))
        Text(stringResource(R.string.empty_title), style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(6.dp))
        Text(
            stringResource(if (connected) R.string.empty_body else R.string.empty_body_off),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 24.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
    }
}

@Composable
private fun KeepAliveCard() {
    val context = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }
    val canHeal = remember(tick) { Watchdog.canHeal(context) }
    val battery = remember(tick) { Watchdog.batteryUnrestricted(context) }
    if (canHeal && battery) return

    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)) {
        Column(Modifier.padding(18.dp)) {
            Text(stringResource(R.string.keep_title), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(
                stringResource(R.string.keep_body),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            if (!battery) {
                Spacer(Modifier.height(14.dp))
                Text(stringResource(R.string.keep_battery), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                Text(
                    stringResource(R.string.keep_battery_body),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { askBattery(context) }) { Text(stringResource(R.string.keep_battery_button)) }
            }

            if (!canHeal) {
                Spacer(Modifier.height(14.dp))
                Text(stringResource(R.string.keep_heal), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                Text(
                    stringResource(R.string.keep_heal_body),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    Watchdog.GRANT_COMMAND,
                    style = MaterialTheme.typography.bodySmall,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(MaterialTheme.shapes.small)
                        .background(MaterialTheme.colorScheme.surfaceContainer)
                        .padding(10.dp),
                )
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = {
                    val cm = context.getSystemService(ClipboardManager::class.java)
                    cm.setPrimaryClip(ClipData.newPlainText("adb", Watchdog.GRANT_COMMAND))
                    Toast.makeText(context, R.string.copied, Toast.LENGTH_SHORT).show()
                }) { Text(stringResource(R.string.copy_command)) }
            }
        }
    }
}

private fun askBattery(context: Context) {
    val direct = Intent(
        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
        Uri.parse("package:${context.packageName}"),
    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    if (runCatching { context.startActivity(direct) }.isFailure) openAppInfo(context)
}

private fun openAccessibility(context: Context) {
    runCatching {
        context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

private fun openAppInfo(context: Context) {
    runCatching {
        context.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    }
}
