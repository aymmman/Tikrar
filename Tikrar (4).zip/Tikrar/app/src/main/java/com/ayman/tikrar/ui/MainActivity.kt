package com.ayman.tikrar.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ayman.tikrar.data.MacroStore
import com.ayman.tikrar.engine.Engine
import com.ayman.tikrar.engine.RecState
import com.ayman.tikrar.engine.Watchdog
import com.ayman.tikrar.model.Macro
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onResume() {
        super.onResume()
        // Opening the app is a good moment to switch the service back on if it was turned off.
        if (!Engine.connected.value) Watchdog.heal(this, kick = Watchdog.isListed(this))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        MacroStore.init(this)
        setContent {
            TikrarTheme { AppRoot() }
        }
    }
}

@Composable
private fun AppRoot() {
    val context = LocalContext.current
    val macros by MacroStore.macros.collectAsStateWithLifecycle()
    val connected by Engine.connected.collectAsStateWithLifecycle()
    val recording by Engine.recording.collectAsStateWithLifecycle()
    val playing by Engine.playing.collectAsStateWithLifecycle()
    var openId by rememberSaveable { mutableStateOf<String?>(null) }

    val askNotifications = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val open = openId?.let { id -> macros.firstOrNull { it.id == id } }
    if (open != null) {
        BackHandler { openId = null }
        MacroScreen(macro = open, playing = playing, connected = connected, onBack = { openId = null })
    } else {
        HomeScreen(
            macros = macros,
            connected = connected,
            recording = recording,
            playing = playing,
            onOpen = { openId = it },
        )
    }

    val rec = recording
    if (rec is RecState.Done) {
        SaveRecordingDialog(
            steps = rec.steps,
            suggestedName = nextName(context, macros),
            onSave = { name ->
                val macro = Macro(
                    id = UUID.randomUUID().toString(),
                    name = name,
                    steps = rec.steps,
                    createdAt = System.currentTimeMillis(),
                )
                MacroStore.upsert(macro)
                Engine.clearRecording()
                openId = macro.id
            },
            onDiscard = { Engine.clearRecording() },
        )
    }
}

private fun nextName(context: android.content.Context, macros: List<Macro>): String {
    var n = macros.size + 1
    while (true) {
        val candidate = context.getString(com.ayman.tikrar.R.string.default_name, n)
        if (macros.none { it.name == candidate }) return candidate
        n++
    }
}
