package com.ayman.tikrar

import android.app.Application
import com.ayman.tikrar.data.MacroStore
import com.ayman.tikrar.engine.Notifications
import com.ayman.tikrar.engine.Watchdog

class TikrarApp : Application() {
    override fun onCreate() {
        super.onCreate()
        MacroStore.init(this)
        Notifications.createChannels(this)
        Watchdog.schedule(this)
        Watchdog.heal(this)
    }
}
