package com.ayman.tikrar.engine

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings

/**
 * Keeps the accessibility service switched on.
 *
 * Android only lets an app flip its own accessibility switch if it holds WRITE_SECURE_SETTINGS,
 * which can be granted once from a computer:
 *   adb shell pm grant com.ayman.tikrar android.permission.WRITE_SECURE_SETTINGS
 * With it, Tikrar turns itself back on whenever it finds itself off: on boot, every 15 minutes,
 * when the app opens, and right before any recording has to run.
 */
object Watchdog {

    const val GRANT_COMMAND = "adb shell pm grant com.ayman.tikrar android.permission.WRITE_SECURE_SETTINGS"

    private const val KEY = Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES

    fun canHeal(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED

    fun batteryUnrestricted(ctx: Context): Boolean =
        ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)

    private fun me(ctx: Context) = ComponentName(ctx.packageName, TikrarService::class.java.name)

    private fun entries(ctx: Context): List<String> =
        Settings.Secure.getString(ctx.contentResolver, KEY)
            ?.split(':')
            ?.filter { it.isNotBlank() }
            .orEmpty()

    private fun isMine(ctx: Context, entry: String): Boolean =
        ComponentName.unflattenFromString(entry) == me(ctx)

    fun isListed(ctx: Context): Boolean = entries(ctx).any { isMine(ctx, it) }

    /**
     * Makes sure the service is switched on. With [kick], a service that is listed as on but
     * isn't actually running gets switched off and on again so the system rebinds it.
     * Returns true when the service is on, or has just been turned on.
     */
    fun heal(ctx: Context, kick: Boolean = false): Boolean {
        val listed = isListed(ctx)
        if (listed && !kick) return true
        if (!canHeal(ctx)) return listed && Engine.connected.value

        val cr = ctx.contentResolver
        val others = entries(ctx).filterNot { isMine(ctx, it) }
        val mine = me(ctx).flattenToString()
        return runCatching {
            if (listed) Settings.Secure.putString(cr, KEY, others.joinToString(":"))
            Settings.Secure.putString(cr, KEY, (others + mine).joinToString(":"))
            Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
        }.isSuccess
    }

    fun schedule(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(
            ctx, 0, Intent(ctx, WatchdogReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        am.cancel(pi)
        if (!canHeal(ctx)) return
        am.setInexactRepeating(
            AlarmManager.ELAPSED_REALTIME_WAKEUP,
            SystemClock.elapsedRealtime() + AlarmManager.INTERVAL_FIFTEEN_MINUTES,
            AlarmManager.INTERVAL_FIFTEEN_MINUTES,
            pi,
        )
    }
}

class WatchdogReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Watchdog.heal(context, kick = !Engine.connected.value)
    }
}
