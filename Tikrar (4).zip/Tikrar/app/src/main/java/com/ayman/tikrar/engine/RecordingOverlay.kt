package com.ayman.tikrar.engine

import android.annotation.SuppressLint
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.ayman.tikrar.R
import kotlin.math.abs

/**
 * Small floating pill shown over every app while recording.
 * Uses an accessibility overlay, so no "draw over other apps" permission is needed,
 * and touches on it never end up in the recording.
 */
internal class RecordingOverlay(
    private val svc: TikrarService,
    private val onStop: () -> Unit,
    private val onCancel: () -> Unit,
) {
    private var root: View? = null
    private var counter: TextView? = null
    private val wm: WindowManager
        get() = svc.getSystemService(WindowManager::class.java)

    private fun dp(v: Int): Int = (v * svc.resources.displayMetrics.density).toInt()

    @SuppressLint("ClickableViewAccessibility")
    fun show() {
        if (root != null) return

        val pill = LinearLayout(svc).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(6), dp(6), dp(6))
            background = GradientDrawable().apply {
                cornerRadius = dp(28).toFloat()
                setColor(0xF0101614.toInt())
                setStroke(dp(1), 0x33FFFFFF)
            }
            elevation = dp(8).toFloat()
        }

        val dot = View(svc).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFFE5484D.toInt())
            }
        }
        pill.addView(dot, LinearLayout.LayoutParams(dp(10), dp(10)))

        counter = TextView(svc).apply {
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(dp(10), 0, dp(12), 0)
        }
        pill.addView(counter)

        val stop = TextView(svc).apply {
            text = svc.getString(R.string.overlay_stop)
            setTextColor(0xFF003731.toInt())
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(18), dp(9), dp(18), dp(9))
            background = GradientDrawable().apply {
                cornerRadius = dp(22).toFloat()
                setColor(0xFF7DD3C5.toInt())
            }
            setOnClickListener { onStop() }
        }
        pill.addView(stop)

        val cancel = TextView(svc).apply {
            text = "✕"
            contentDescription = svc.getString(R.string.cancel)
            setTextColor(0xFFBEC6C3.toInt())
            textSize = 16f
            setPadding(dp(14), dp(6), dp(10), dp(6))
            setOnClickListener { onCancel() }
        }
        pill.addView(cancel)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(56)
        }

        // Drag the pill out of the way by holding its left side.
        var startX = 0
        var startY = 0
        var downX = 0f
        var downY = 0f
        pill.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x
                    startY = lp.y
                    downX = e.rawX
                    downY = e.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (abs(dx) > 4 || abs(dy) > 4) {
                        lp.x = startX + dx.toInt()
                        lp.y = (startY + dy.toInt()).coerceAtLeast(0)
                        runCatching { wm.updateViewLayout(v, lp) }
                    }
                    true
                }
                else -> false
            }
        }

        if (runCatching { wm.addView(pill, lp) }.isSuccess) root = pill
        update(0)
    }

    fun update(count: Int) {
        counter?.text = svc.resources.getQuantityString(R.plurals.steps, count, count)
    }

    fun hide() {
        root?.let { v -> runCatching { wm.removeView(v) } }
        root = null
        counter = null
    }
}
