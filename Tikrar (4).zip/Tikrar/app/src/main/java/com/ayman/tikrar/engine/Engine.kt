package com.ayman.tikrar.engine

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.PowerManager
import com.ayman.tikrar.data.MacroStore
import com.ayman.tikrar.model.Step
import com.ayman.tikrar.schedule.WakeActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.lang.ref.WeakReference

sealed interface RecState {
    data object Idle : RecState
    data class Active(val count: Int) : RecState
    data class Done(val steps: List<Step>) : RecState
}

data class PlayState(
    val macroId: String,
    val name: String,
    val index: Int,
    val total: Int,
)

/** Thin bridge between the UI / receivers and the running accessibility service. */
object Engine {

    private var ref: WeakReference<TikrarService>? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val connectedState = MutableStateFlow(false)
    val connected: StateFlow<Boolean> = connectedState.asStateFlow()

    internal val recordingState = MutableStateFlow<RecState>(RecState.Idle)
    val recording: StateFlow<RecState> = recordingState.asStateFlow()

    internal val playingState = MutableStateFlow<PlayState?>(null)
    val playing: StateFlow<PlayState?> = playingState.asStateFlow()

    private val service: TikrarService?
        get() = ref?.get()

    internal fun attach(s: TikrarService) {
        ref = WeakReference(s)
        connectedState.value = true
    }

    internal fun detach(s: TikrarService) {
        if (ref?.get() !== s) return
        ref = null
        connectedState.value = false
        playingState.value = null
        if (recordingState.value is RecState.Active) recordingState.value = RecState.Idle
    }

    fun startRecording(): Boolean = service?.startRecording() ?: false

    fun cancelRecording() {
        service?.cancelRecording()
        recordingState.value = RecState.Idle
    }

    fun clearRecording() {
        recordingState.value = RecState.Idle
    }

    fun play(context: Context, id: String): Boolean {
        val macro = MacroStore.get(id) ?: return false
        if (macro.steps.isEmpty()) return false
        service?.let { return it.play(macro) }

        // Switched off (by accident, a crash or the system): try to bring it back first.
        val app = context.applicationContext
        if (!Watchdog.heal(app, kick = true)) {
            Notifications.serviceOff(app)
            return false
        }
        scope.launch {
            val up = withTimeoutOrNull(8_000L) { connected.first { it } }
            val s = service
            if (up == null || s == null) {
                Notifications.serviceOff(app)
            } else {
                delay(400)
                s.play(macro)
            }
        }
        return true
    }

    fun stop() {
        service?.stopPlayback()
    }

    /** Used by alarms: wake the screen first if needed, then play. */
    fun runFromBackground(context: Context, id: String) {
        val power = context.getSystemService(PowerManager::class.java)
        val keyguard = context.getSystemService(KeyguardManager::class.java)
        if (!power.isInteractive || keyguard.isKeyguardLocked) {
            val wake = Intent(context, WakeActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                .putExtra(WakeActivity.EXTRA_ID, id)
            runCatching { context.startActivity(wake) }.onFailure { play(context, id) }
        } else {
            play(context, id)
        }
    }
}
