package com.ayman.tikrar.model

enum class StepType {
    LAUNCH, CLICK, LONG_CLICK, SET_TEXT, SCROLL,
    BACK, HOME, RECENTS, NOTIFICATIONS, WAIT, LOCK, SCREENSHOT, CLOSE_APP,
}

/** Everything we know about the view the user touched, so it can be found again later. */
data class Target(
    val pkg: String,
    val viewId: String?,
    val label: String?,
    val cls: String?,
    val path: String,
    val cx: Float,
    val cy: Float,
    val clickable: Boolean,
)

data class Step(
    val type: StepType,
    val delayMs: Long = 0L,
    val fixedDelay: Boolean = false,
    val timeoutMs: Long = DEFAULT_TIMEOUT,
    val pkg: String? = null,
    val appLabel: String? = null,
    val target: Target? = null,
    val text: String? = null,
    val scrollX: Int = 0,
    val scrollY: Int = 0,
    val byPosition: Boolean = false,
    val fresh: Boolean = true,
) {
    val isGlobal: Boolean
        get() = type in GLOBALS

    companion object {
        const val DEFAULT_TIMEOUT = 10_000L
        private val GLOBALS = setOf(
            StepType.BACK, StepType.HOME, StepType.RECENTS, StepType.NOTIFICATIONS,
            StepType.LOCK, StepType.SCREENSHOT,
        )
    }
}

/** days uses Calendar.DAY_OF_WEEK values. Empty means "run once". */
data class Schedule(
    val enabled: Boolean = false,
    val hour: Int = 8,
    val minute: Int = 0,
    val days: Set<Int> = emptySet(),
)

data class Macro(
    val id: String,
    val name: String,
    val steps: List<Step>,
    val createdAt: Long,
    val repeat: Int = 1,
    val smartTiming: Boolean = true,
    val autoHandle: Boolean = true,
    val schedule: Schedule = Schedule(),
)
