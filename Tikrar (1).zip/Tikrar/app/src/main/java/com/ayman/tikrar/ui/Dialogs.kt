@file:OptIn(ExperimentalMaterial3Api::class)

package com.ayman.tikrar.ui

import android.content.Intent
import android.content.pm.PackageManager
import android.text.format.DateFormat
import androidx.annotation.StringRes
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.ayman.tikrar.R
import com.ayman.tikrar.model.Step
import com.ayman.tikrar.model.StepType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun SaveRecordingDialog(
    steps: List<Step>,
    suggestedName: String,
    onSave: (String) -> Unit,
    onDiscard: () -> Unit,
) {
    val context = LocalContext.current
    var name by remember { mutableStateOf(suggestedName) }
    if (steps.isEmpty()) {
        AlertDialog(
            onDismissRequest = onDiscard,
            title = { Text(stringResource(R.string.save_title)) },
            text = { Text(stringResource(R.string.nothing_recorded)) },
            confirmButton = { TextButton(onClick = onDiscard) { Text(stringResource(R.string.done)) } },
        )
        return
    }
    AlertDialog(
        onDismissRequest = { },
        title = { Text(stringResource(R.string.save_title)) },
        text = {
            Column {
                Text(context.resources.getQuantityString(R.plurals.steps_captured, steps.size, steps.size))
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(60) },
                    label = { Text(stringResource(R.string.name_hint)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(name.trim().ifEmpty { suggestedName }) }) {
                Text(stringResource(R.string.save))
            }
        },
        dismissButton = { TextButton(onClick = onDiscard) { Text(stringResource(R.string.discard)) } },
    )
}

@Composable
fun TextInputDialog(title: String, initial: String, onDismiss: () -> Unit, onDone: (String) -> Unit) {
    var value by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = value,
                onValueChange = { value = it.take(60) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
        },
        confirmButton = {
            TextButton(onClick = { onDone(value.trim().ifEmpty { initial }) }) { Text(stringResource(R.string.save)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

@Composable
fun ConfirmDialog(title: String, body: String, confirm: String, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(body) },
        confirmButton = {
            TextButton(onClick = onConfirm) { Text(confirm, color = MaterialTheme.colorScheme.error) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

@Composable
fun StepEditDialog(step: Step, onDismiss: () -> Unit, onSave: (Step) -> Unit) {
    val context = LocalContext.current
    val isWait = step.type == StepType.WAIT
    val hasTarget = step.target != null
    val findsSomething = step.type == StepType.LAUNCH || (hasTarget && !step.isGlobal)

    val startDelay = editableSeconds(step.delayMs)
    var delay by remember { mutableStateOf(startDelay) }
    var timeout by remember { mutableStateOf(editableSeconds(step.timeoutMs)) }
    var text by remember { mutableStateOf(step.text.orEmpty()) }
    var fresh by remember { mutableStateOf(step.fresh) }
    var byPosition by remember { mutableStateOf(step.byPosition) }

    val delayValue = parseSeconds(delay)
    val timeoutValue = parseSeconds(timeout)
    val valid = delayValue != null && (!findsSomething || (timeoutValue != null && timeoutValue >= 1.0))

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(step.title(context), maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                NumberField(
                    value = delay,
                    onChange = { delay = it },
                    label = if (isWait) R.string.wait_label else R.string.delay_label,
                )
                if (findsSomething) {
                    Spacer(Modifier.height(10.dp))
                    NumberField(value = timeout, onChange = { timeout = it }, label = R.string.timeout_label)
                }
                if (step.type == StepType.SET_TEXT) {
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = text,
                        onValueChange = { text = it },
                        label = { Text(stringResource(R.string.text_label)) },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                if (step.type == StepType.LAUNCH) {
                    ToggleRow(R.string.fresh_start, fresh) { fresh = it }
                }
                if ((step.type == StepType.CLICK || step.type == StepType.LONG_CLICK) && hasTarget) {
                    ToggleRow(R.string.by_position, byPosition) { byPosition = it }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = valid,
                onClick = {
                    val ms = ((delayValue ?: 0.0) * 1000).toLong().coerceIn(0L, 600_000L)
                    val to = ((timeoutValue ?: 10.0) * 1000).toLong().coerceIn(1_000L, 120_000L)
                    onSave(
                        step.copy(
                            delayMs = ms,
                            fixedDelay = step.fixedDelay || delay != startDelay,
                            timeoutMs = if (findsSomething) to else step.timeoutMs,
                            text = if (step.type == StepType.SET_TEXT) text else step.text,
                            fresh = fresh,
                            byPosition = byPosition,
                        ),
                    )
                },
            ) { Text(stringResource(R.string.save)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

@Composable
private fun NumberField(value: String, onChange: (String) -> Unit, @StringRes label: Int) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.take(6)) },
        label = { Text(stringResource(label)) },
        singleLine = true,
        isError = parseSeconds(value) == null,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = Modifier.fillMaxWidth(),
    )
}

@Composable
private fun ToggleRow(@StringRes label: Int, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(stringResource(label), modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

private val addable = listOf(
    StepType.LAUNCH to R.string.add_launch,
    StepType.CLOSE_APP to R.string.step_close_current,
    StepType.BACK to R.string.step_back,
    StepType.HOME to R.string.step_home,
    StepType.RECENTS to R.string.step_recents,
    StepType.NOTIFICATIONS to R.string.step_notifications,
    StepType.WAIT to R.string.add_wait,
    StepType.SCREENSHOT to R.string.step_screenshot,
    StepType.LOCK to R.string.step_lock,
)

@Composable
fun AddStepDialog(onDismiss: () -> Unit, onPick: (StepType) -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.add_step)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                addable.forEach { (type, label) ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onPick(type) }
                            .padding(vertical = 12.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            painterResource(stepIcon(type)),
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp),
                        )
                        Spacer(Modifier.width(16.dp))
                        Text(stringResource(label), style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

private data class AppEntry(val pkg: String, val label: String)

@Composable
fun AppPickerDialog(onDismiss: () -> Unit, onPick: (String, String) -> Unit) {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    val apps by produceState<List<AppEntry>?>(initialValue = null) {
        value = withContext(Dispatchers.IO) {
            val pm = context.packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
                .map { AppEntry(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
                .filter { it.pkg != context.packageName }
                .distinctBy { it.pkg }
                .sortedBy { it.label.lowercase() }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.pick_app)) },
        text = {
            Column {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text(stringResource(R.string.search)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                val list = apps
                if (list == null) {
                    CircularProgressIndicator(Modifier.padding(24.dp))
                } else {
                    val shown = list.filter { query.isBlank() || it.label.contains(query.trim(), ignoreCase = true) }
                    LazyColumn(Modifier.heightIn(max = 380.dp)) {
                        items(shown, key = { it.pkg }) { app ->
                            Text(
                                app.label,
                                style = MaterialTheme.typography.bodyLarge,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onPick(app.pkg, app.label) }
                                    .padding(vertical = 12.dp, horizontal = 4.dp),
                            )
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

@Composable
fun TimeDialog(hour: Int, minute: Int, onDismiss: () -> Unit, onDone: (Int, Int) -> Unit) {
    val context = LocalContext.current
    val state = rememberTimePickerState(
        initialHour = hour,
        initialMinute = minute,
        is24Hour = DateFormat.is24HourFormat(context),
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        text = { TimePicker(state = state) },
        confirmButton = {
            TextButton(onClick = { onDone(state.hour, state.minute) }) { Text(stringResource(R.string.done)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}
